// Array Inicial
<?php
$a = array("verde", "vermelho", "azul");
	echo "<br>Array Inicial";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

    //Array_unshift
	array_unshift($a, "ciano");
	echo "<br>Após array_unshift";
	echo "<pre>";
		print_r($a);
	echo "</pre>";


    //Array_push
	array_push($a,"amarelo");

	echo "<br>Após array_push";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

    //Array[] = valor
	$a[] = "preto";
echo "<br>Após array[] = valor";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

    //Array_shift
    $valor = array_shift($a);
	echo "<br>Valor removido: ".$valor;
	echo "<br>Após array_shift";
	echo "<pre>";
		print_r($a);
	echo "</pre>";
	
    //Array_pop
	$valor = array_pop($a);
	echo "<br>Valor removido: ".$valor;
	echo "<br>Após array_pop";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

    //Array_reverse
	$b = array_reverse($a);
	echo "<br>Após array_reverse";
	echo "<pre>";
		print_r($b);
	echo "</pre>";

    //Array_merge
    $a = array("verde", "vermelho");
    $b = array("amarelo", "preto");

    echo '<br>Array $a';
    echo "<pre>";
        print_r($a);
    echo "</pre>";

    echo '<br>Array $b';
    echo "<pre>";
        print_r($b);
    echo "</pre>";

    $c = array_merge($a, $b);

    echo "<br>Após array_merge";
    echo "<pre>";
        print_r($c);
    echo "</pre>";

    //Array_keys, Array_values e count
    $a = array("nome"=>"tiago", "idade"=>15, "curso"=>"INFO");

    echo '<br>print_r($a)';
    echo "<pre>";
        print_r($a);
    echo "</pre>";

    echo '<br>print_r(array_keys($a))';
    echo "<pre>";
        print_r(array_keys($a));
    echo "</pre>";
    
    echo '<br>print_r(array_values($a))';
    echo "<pre>";
        print_r(array_values($a));
    echo "</pre>";

    $qt = count($a);
    echo "<br>Quantidade de Elementos: ".$qt;

    //In_array, sort e r_sort
    $a = array("arroz", "feijão", "trigo", "biscoito");
	
	echo "<br>print_r";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

	$chave = "trigo";
	if(in_array($chave, $a)){
		echo $chave." encontrado<br>";
	}else{
		echo $chave ." não encontrado<br>";
	}

	sort($a);
	echo "<br>Após sort";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

	rsort($a);
	echo "<br>Após rsort";
	echo "<pre>";
		print_r($a);
	echo "</pre>";


    //Asort e arsort
    $a = array("arroz", "feijão", "trigo", "biscoito");
	
	echo "<br>print_r";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

	
	asort($a);
	echo "<br>Após asort";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

	arsort($a);
	echo "<br>Após arsort";
	echo "<pre>";
		print_r($a);
	echo "</pre>";

    //Ksort e krsort
	$b = array("potencia"=>"1.0", "cor"=>"branco", "modelo"=>"palio","opcional"=>"ar condicionado");
	
	echo "<br>print_r";
	echo "<pre>";
		print_r($b);
	echo "</pre>";

	ksort($b);
	echo "<br>Após ksort";
	echo "<pre>";
		print_r($b);
	echo "</pre>";

	sort($b);	//testar com asort também
	echo "<br>Após sort";
	echo "<pre>";
		print_r($b);
	echo "</pre>";

    //Explode e implode
    $data = "05/08/2019";
	$a = explode("/",$data);

	echo "<br>dia: ".$a[0];
	echo "<br>mês: ".$a[1];
	echo "<br>ano: ". $a[2];
	echo "<br>";
	
	$b = ["05","08","2019"];

	echo "<br>print_r";
	echo "<pre>";
		print_r($b);
	echo "</pre>";

	$c = implode("/", $b);

	echo "<br>Data: ". $c;
