<?php 

	echo "Olá ".$_POST["nome"]."<br>"; 
	echo "Seu endereço de e-mail é: ".$_POST["email"]."<br>";

?>