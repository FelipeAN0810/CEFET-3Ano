<?php 

	echo "Olá ".$_GET["nome"]."<br>"; 
	echo "Seu endereço de e-mail é: ".$_GET["email"]."<br>";

?>