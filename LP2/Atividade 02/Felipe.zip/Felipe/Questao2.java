public class Questao2{
	public static void main(String args[]){
		int i = 0;
		
		System.out.println("Numero\t\tQuadrado\tCubo");
		for(i = 0; i <= 10; i++){
		System.out.println(i + "\t\t" + (i * i) + "\t\t" + (i * i * i));
		}
	}
}