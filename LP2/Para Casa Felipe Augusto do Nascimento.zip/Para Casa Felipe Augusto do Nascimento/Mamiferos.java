public abstract class Mamiferos extends Animais{
    public abstract void fazerBarulho();
    public abstract void correr();
}
