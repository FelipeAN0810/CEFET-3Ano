public class Gatos extends Mamiferos{

    public void fazerBarulho(){

    }

    public void correr(){

    }

    public void som(){
        System.out.println("Miauuuuu");
    }
}

