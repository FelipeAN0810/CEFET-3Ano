public class Vaca extends Mamiferos{
    
    public void som(){
        System.out.println("MUUUUUUHHH!!!");
    }

    public void fazerBarulho(){
        System.out.println("Nham nham");
    }

    public void correr(){

    }
}
