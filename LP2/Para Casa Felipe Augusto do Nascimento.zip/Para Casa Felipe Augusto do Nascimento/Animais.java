public class Animais {
    public int idade;
    public String nome;
    
    public Animais(){
        idade = 10;
        nome = "Jubiscreuzo";
    }

    public void som(){
        System.out.println(nome + " ");
    }
}