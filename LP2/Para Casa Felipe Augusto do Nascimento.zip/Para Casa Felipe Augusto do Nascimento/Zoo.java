import java.util.ArrayList;

public class Zoo {
    public static void main(String[] args){

        Cachorro cachorro;
        Vaca vaca;
        Gatos gato;

        cachorro = new Cachorro("Joaquim");
        vaca = new Vaca();
        gato = new Gatos();

        cachorro.fazerBarulho();
        vaca.fazerBarulho();
        gato.fazerBarulho();

        cachorro.som();
        vaca.som();
        gato.som();

        ArrayList<Mamiferos> listaMamiferos = new ArrayList<Mamiferos>();

        listaMamiferos.add(cachorro);
        listaMamiferos.add(vaca);
        listaMamiferos.add(gato);

        for(Mamiferos mamiferos : listaMamiferos){
            mamiferos.fazerBarulho();
            mamiferos.som();
        }
    }
}
