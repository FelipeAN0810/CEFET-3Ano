public class Cachorro extends Mamiferos {
    private static int conta = 0;
    private int id = 0;

    public Cachorro() {
    }

    public Cachorro(String nome1) {
        nome = nome1;
        id = conta++;
    }

    public void som() {
        System.out.println("Au au");
    }

    public void SetId(int id) {
        this.id = id;
    }

    public int GetId() {
        return id;
    }

    public void fazerBarulho() {
        System.out.println("Nham nham");
    }

    public void correr(){

    }

}
