import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';
import Container from '@mui/material/Container';
import PostMessage from './components/PostMessage';
import AppBar from '@mui/material/AppBar';
import Typography from '@mui/material/Typography';

function App() {
  return (
    <Container maxWidth="lg">
      <AppBar position="static">
        <Typography variant="h3" align="center">
          Post Box
        </Typography>
      </AppBar>
      <PostMessage/>
      <ToastContainer/>
    </Container>
  );
}

export default App;