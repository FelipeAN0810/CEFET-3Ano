import React, {Fragment} from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

const styleMessage = {
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'right',
}

const style = {
  margin: 5,
}

const PostMessageList = (props, posts) => {
  return(
    <List>

      {props.posts.map( (post,index) => {
        return(
          <Fragment key={index}>
            <ListItem>
              <ListItemText>
                <Typography variant = "h5">
                  {post.title}
                </Typography>
                  <div>
                    {post.message}
                  </div>
                <div style={styleMessage}>
                  <Button variant = "contained" color="primary" size="small" style={style} onClick = {() => { props.setAction({currentId: post._id, type: props.ACTION_TYPES.UPDATE}) }}>
                    Edit
                  </Button>
                  <Button variant = "contained" color="error" size="small" style={style} onClick = {() => { props.setAction({currentId: post._id, type: props.ACTION_TYPES.DELETE}) }}>
                    Delete
                  </Button>
                </div>
              </ListItemText>
            </ListItem>
            <Divider component = "li"/>
          </Fragment>
        )
      })}
    </List>

  );
}

export default PostMessageList;