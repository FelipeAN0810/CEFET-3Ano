import React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';

const style = {
  margin: 6,
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'center',
};

const styleMessage = {
  margin: 6,
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'center',
}

const styleButton = {
  margin: 6,
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'center',
  width: '50%'
}

const PostMessageForm = (props) => {

  return(
    <form noValidate autoComplete="off" style={style} onSubmit = {props.handleSubmit}>
      <TextField name="title" label="Title" variant="outlined" fullWidth style={style} value = {props.values.title} onChange = {props.handleInputChange} {...(props.errors.title ? {error:true, helperText:props.errors.title}: null) }/>
      <TextField name="message" label="Message" variant="outlined" fullWidth style={styleMessage} value = {props.values.message} multiline rows={4} onChange = {props.handleInputChange} {...(props.errors.message ? {error:true, helperText:props.errors.message}: null) }/>
      <Button variant="contained" color="primary" size="large" type="submit" style={styleButton}>
        Submit
      </Button>
    </form>
  );
}

export default PostMessageForm;