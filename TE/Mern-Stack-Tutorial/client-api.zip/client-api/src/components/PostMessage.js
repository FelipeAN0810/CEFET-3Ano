import React, {useState,useEffect} from 'react';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import PostMessageForm from './PostMessageForm';
import PostMessageList from './PostMessageList';
import {fetchAllPost} from '../services/postService';
import {createPost} from '../services/postService';
import {updatePost} from '../services/postService';
import {removePost} from '../services/postService';
import {toast} from 'react-toastify';

const style = {
  margin: 12,
  padding: 5,
}

const initialFieldValues = {
  title: '',
  message: ''
}

const ACTION_TYPES = {
  FETCH_ALL: 'FETCH_ALL',
  CREATE: 'CREATE',
  UPDATE: 'UPDATE',
  DELETE: 'DELETE',
}

const initialAction = {
  currentId: 0,
  type: ACTION_TYPES.FETCH_ALL
}

const onSuccess = (method) => {
  switch (method) {
    case "create":
      toast.success("Post criado com sucesso!", {
        theme: "colored"
      })
      break;

    case "delete":
      toast.error("Post deletado com sucesso!", {
        theme: "colored"
      })
      break;

    case "update":
      toast.info("Post atualizado com sucesso!", {
        theme: "colored"
      })
      break;

    default:
      toast.warn("Erro.", {
        theme: "dark",
        icon: false
      })
      break;
  }
}

const PostMessage = (props) => {

  const [posts, setPosts] = useState([])
  const [values, setValues] = useState(initialFieldValues)
  const [errors, setErrors] = useState({})
  const [action, setAction] = useState(initialAction)

  const validate = () => {
    let temp = errors
    temp.title = values.title ? "" : "This field is required."
    temp.message = values.message ? "" : "This field is required."

    setErrors({
      ...temp
    })

    //returns true if all temp values are empty
    return !(temp.title || temp.message)
  }

  useEffect(() => {
    fetchAllPost().then(setPosts)
  }, [posts]);

  useEffect(() => {

    if (action.type === ACTION_TYPES.UPDATE) {

      //set values to the inputs
      setValues({
        ...posts.find(x => x._id === action.currentId)
      })

      //clean errors
      setErrors({})
    }

    if (action.type === ACTION_TYPES.DELETE) {
      handleDelete(action.currentId)
    }


  }, [action]);

  const handleInputChange = e => {

    const {
      name,
      value
    } = e.target

    setValues({
      ...values,
      [name]: value
    })
  }

  const handleSubmit = e => {
    //prevent automatic reloads 
    e.preventDefault();

    if (validate()) {
      if (action.type === ACTION_TYPES.UPDATE) {

        updatePost(action.currentId, values).then(() => {
          onSuccess("update")
          setAction({
            ...action,
            type: ACTION_TYPES.FETCH_ALL
          })
        })
        setValues(initialFieldValues)
      } else {

        //include new post
        createPost(values)
          .then(
            //update posts with the new entry
            fetchAllPost().then(setPosts),

          )
        onSuccess("create")
        setAction({
          ...action,
          type: ACTION_TYPES.FETCH_ALL
        })
      }

      setValues(initialFieldValues)
    }
  }

  const handleDelete = id => {

    if (window.confirm('Você tem certeza que deseja excluir?')) {
      removePost(id)
        .then(() => {
          onSuccess("delete")
          //clear form fields
          setValues(initialFieldValues)
          //initial action
          setAction(initialAction)
          //clear errors
          setErrors({})
        })
    }
  }

  return(
    <Grid container>
      <Grid item xs={5}>
        <Paper style={style}>
          <PostMessageForm {...{values, handleInputChange, handleSubmit, errors}}/>
        </Paper>
      </Grid>
      <Grid item xs={7}>
        <Paper style={style}>
          <PostMessageList {...{posts, setAction, ACTION_TYPES}}/>
        </Paper>
      </Grid>
    </Grid>
  );
}

export default PostMessage;