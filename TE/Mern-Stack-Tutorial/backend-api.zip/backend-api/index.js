require ('./db')
const express = require('express')
require("dotenv").config();

var postMessageRoutes = require('./controllers/postMessageController')

var app = express()
app.use(express.json())
app.use(express.urlencoded({ extended: true}))

app.use('/', postMessageRoutes)

// initial route
app.get("/", (req, res) => {
    res.send("Welcome to the application." );
});

const PORT = 4000;

app.listen(PORT, () => console.log(`Server started at: ${PORT}`))
