const express = require('express');
var router = express.Router();
var ObjectID = require('mongoose').Types.ObjectId

//reference for the scheme
var {PostMessage} = require('../models/postMessageModel')

//save record
router.post('/postMessages/', (req, res) => {
    var newRecord = new PostMessage({
        title: req.body.title,
        message: req.body.message
    })

    newRecord.save((err, doc) => {
        if(!err) res.send(doc)
        else console.log('Error while creating new record: ' + JSON.stringify(err,undefined,2))
    })
})

//get all records
router.get('/postMessages/', (req, res) => {
    PostMessage.find((err,docs) =>{
        if(!err) res.send(docs)
        else console.log('Error while retrieving all records: ' + JSON.stringify(err,undefined,2))
    })
})

//reference for the scheme
var {PostMessage} = require('../models/postMessageModel')

//update record
router.put('/postMessages/:id', (req, res) => {
    if(!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id: ' + req.params.id)

    var updatedRecord = {
        title: req.body.title,
        message: req.body.message
    }

    PostMessage.findByIdAndUpdate(req.params.id, {$set: updatedRecord}, {new:true}, (err, docs) => {
        if(!err) res.send(docs)
        else console.log('Error while updating a record: ' + JSON.stringify(err,undefined,2))
    })
})

//delete object
router.delete('/postMessages/:id', (req, res) => {
    if(!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id: ' + req.params.id)

    PostMessage.findByIdAndDelete(req.params.id, (err, docs) => {
        if(!err) res.send(docs)
        else console.log('Error while deleting a record: ' + JSON.stringify(err,undefined,2))
    })
})

module.exports = router;
